import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile } from '../types';

// NOTE: Demo-only mock password hashing for client-side storage.
// In a real production application, password hashing and verification is handled securely on the server with bcrypt/argon2.
export function demoHashPassword(password: string): string {
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0; // Convert to 32bit integer
  }
  return `demo_h_${Math.abs(hash).toString(16)}_${password.length}`;
}

interface StoredUserRecord {
  id: string;
  name: string;
  email: string;
  phone: string;
  passwordHash: string;
  createdAt: string;
  savedPropertyIds: string[];
}

interface AuthContextType {
  currentUser: UserProfile | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  signup: (data: { name: string; email: string; phone: string; password: string }) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  savedPropertyIds: string[];
  toggleSaveProperty: (id: string) => boolean; // returns true if now saved, false if unsaved
  isPropertySaved: (id: string) => boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const USERS_STORAGE_KEY = 'avenue_registered_users_v2';
const SESSION_STORAGE_KEY = 'avenue_active_session_v2';
const GUEST_SAVED_KEY = 'avenue_guest_saved_homes_v2';

// Initial demo user with authentic Pakistani credentials
const DEFAULT_DEMO_USERS: StoredUserRecord[] = [
  {
    id: 'user_ahmed_raza',
    name: 'Ahmed Raza',
    email: 'ahmed.raza@avenue.pk',
    phone: '+92 300 8452100',
    passwordHash: demoHashPassword('avenue2025'),
    createdAt: '2024-01-15T10:00:00.000Z',
    savedPropertyIds: ['obsidian-residence', 'zenith-pavilion'],
  },
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [guestSavedIds, setGuestSavedIds] = useState<string[]>([]);

  // Initialize users and session from localStorage
  useEffect(() => {
    try {
      const storedUsersRaw = localStorage.getItem(USERS_STORAGE_KEY);
      if (!storedUsersRaw) {
        localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(DEFAULT_DEMO_USERS));
      }

      const activeSessionRaw = localStorage.getItem(SESSION_STORAGE_KEY);
      if (activeSessionRaw) {
        const user: UserProfile = JSON.parse(activeSessionRaw);
        setCurrentUser(user);
      }

      const guestSavedRaw = localStorage.getItem(GUEST_SAVED_KEY);
      if (guestSavedRaw) {
        setGuestSavedIds(JSON.parse(guestSavedRaw));
      }
    } catch (e) {
      console.error('Failed to load local storage auth session', e);
    }
  }, []);

  const getUsers = (): StoredUserRecord[] => {
    try {
      const data = localStorage.getItem(USERS_STORAGE_KEY);
      return data ? JSON.parse(data) : DEFAULT_DEMO_USERS;
    } catch {
      return DEFAULT_DEMO_USERS;
    }
  };

  const saveUsers = (users: StoredUserRecord[]) => {
    localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
  };

  const login = async (email: string, password: string): Promise<{ success: boolean; error?: string }> => {
    const users = getUsers();
    const normalizedEmail = email.trim().toLowerCase();
    const user = users.find((u) => u.email.toLowerCase() === normalizedEmail);

    if (!user) {
      return { success: false, error: 'No account found with this email address.' };
    }

    const hashedInput = demoHashPassword(password);
    if (user.passwordHash !== hashedInput) {
      return { success: false, error: 'Incorrect password. Please verify and try again.' };
    }

    const profile: UserProfile = {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      createdAt: user.createdAt,
      savedPropertyIds: user.savedPropertyIds || [],
    };

    setCurrentUser(profile);
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(profile));
    return { success: true };
  };

  const signup = async (data: {
    name: string;
    email: string;
    phone: string;
    password: string;
  }): Promise<{ success: boolean; error?: string }> => {
    const users = getUsers();
    const normalizedEmail = data.email.trim().toLowerCase();

    if (users.some((u) => u.email.toLowerCase() === normalizedEmail)) {
      return { success: false, error: 'An account with this email address already exists.' };
    }

    const newRecord: StoredUserRecord = {
      id: `user_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      name: data.name.trim(),
      email: normalizedEmail,
      phone: data.phone.trim(),
      passwordHash: demoHashPassword(data.password),
      createdAt: new Date().toISOString(),
      savedPropertyIds: guestSavedIds, // merge any homes saved prior to signing up
    };

    const updatedUsers = [...users, newRecord];
    saveUsers(updatedUsers);

    const profile: UserProfile = {
      id: newRecord.id,
      name: newRecord.name,
      email: newRecord.email,
      phone: newRecord.phone,
      createdAt: newRecord.createdAt,
      savedPropertyIds: newRecord.savedPropertyIds,
    };

    setCurrentUser(profile);
    localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(profile));
    return { success: true };
  };

  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem(SESSION_STORAGE_KEY);
  };

  const isPropertySaved = (id: string): boolean => {
    if (currentUser) {
      return currentUser.savedPropertyIds.includes(id);
    }
    return guestSavedIds.includes(id);
  };

  const toggleSaveProperty = (id: string): boolean => {
    if (currentUser) {
      const alreadySaved = currentUser.savedPropertyIds.includes(id);
      const newSavedIds = alreadySaved
        ? currentUser.savedPropertyIds.filter((pId) => pId !== id)
        : [...currentUser.savedPropertyIds, id];

      const updatedProfile: UserProfile = {
        ...currentUser,
        savedPropertyIds: newSavedIds,
      };

      setCurrentUser(updatedProfile);
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(updatedProfile));

      // Also persist to users db
      const users = getUsers();
      const updatedUsers = users.map((u) => (u.id === currentUser.id ? { ...u, savedPropertyIds: newSavedIds } : u));
      saveUsers(updatedUsers);

      return !alreadySaved;
    } else {
      // Guest mode
      const alreadySaved = guestSavedIds.includes(id);
      const newSaved = alreadySaved ? guestSavedIds.filter((pId) => pId !== id) : [...guestSavedIds, id];
      setGuestSavedIds(newSaved);
      localStorage.setItem(GUEST_SAVED_KEY, JSON.stringify(newSaved));
      return !alreadySaved;
    }
  };

  const savedPropertyIds = currentUser ? currentUser.savedPropertyIds : guestSavedIds;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        isAuthenticated: !!currentUser,
        login,
        signup,
        logout,
        savedPropertyIds,
        toggleSaveProperty,
        isPropertySaved,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
