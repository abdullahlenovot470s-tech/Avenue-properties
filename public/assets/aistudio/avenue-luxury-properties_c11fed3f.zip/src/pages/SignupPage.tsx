import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Eye, EyeOff, Lock, Mail, User, Phone, CheckCircle2, ArrowRight, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { SafeImage } from '../components/common/SafeImage';
import { HERO_ASSETS } from '../data/realEstateData';

export const SignupPage: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    agreeTerms: false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  const { signup } = useAuth();
  const { showToast } = useToast();
  const navigate = useNavigate();

  const validate = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.name.trim()) {
      newErrors.name = 'Full name is required.';
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim() || !emailRegex.test(formData.email.trim())) {
      newErrors.email = 'Please provide a valid email address.';
    }

    if (!formData.phone.trim()) {
      newErrors.phone = 'Contact phone number is required.';
    }

    if (!formData.password) {
      newErrors.password = 'Password is required.';
    } else if (formData.password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters long.';
    }

    if (formData.password !== formData.confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match.';
    }

    if (!formData.agreeTerms) {
      newErrors.agreeTerms = 'You must acknowledge the terms and privacy covenants.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setLoading(true);
    const result = await signup({
      name: formData.name,
      email: formData.email,
      phone: formData.phone,
      password: formData.password,
    });
    setLoading(false);

    if (result.success) {
      showToast('Assalam o Alaikum! Your Avenue client profile has been created.', 'success');
      navigate('/profile', { replace: true });
    } else {
      setErrors((prev) => ({
        ...prev,
        email: result.error || 'Failed to create account.',
      }));
    }
  };

  return (
    <div className="min-h-screen pt-28 pb-16 px-4 sm:px-6 flex items-center justify-center">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-5xl bg-white rounded-[28px] sm:rounded-[36px] overflow-hidden shadow-2xl border border-slate-100 grid grid-cols-1 lg:grid-cols-12 min-h-[680px]"
      >
        {/* Left Half: Clean White Form Card */}
        <div className="lg:col-span-6 p-8 sm:p-12 md:p-14 flex flex-col justify-center">
          <div className="max-w-md mx-auto w-full">
            <div className="mb-6">
              <span className="text-[10px] font-display uppercase tracking-widest text-[#2F4B73] font-bold block mb-1">
                Client Registration
              </span>
              <h2 className="font-display font-extrabold text-2xl sm:text-3xl text-[#1B2A44] uppercase tracking-tight">
                JOIN AVENUE
              </h2>
              <p className="font-body text-xs sm:text-sm text-slate-500 mt-1">
                Register for confidential access to architectural residences in Pakistan.
              </p>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3.5">
              {/* Full Name */}
              <div>
                <label className="block text-[11px] font-display uppercase tracking-wider text-slate-700 font-semibold mb-1">
                  Full Name
                </label>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="e.g. Ayesha Siddiqui"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50/60 text-slate-900 text-xs sm:text-sm focus:outline-none focus:border-[#2F4B73] focus:bg-white transition-all"
                  />
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                </div>
                {errors.name && <p className="text-[11px] text-rose-500 mt-1">{errors.name}</p>}
              </div>

              {/* Email Address */}
              <div>
                <label className="block text-[11px] font-display uppercase tracking-wider text-slate-700 font-semibold mb-1">
                  Email Address
                </label>
                <div className="relative">
                  <input
                    type="email"
                    placeholder="e.g. ayesha.siddiqui@gmail.com"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50/60 text-slate-900 text-xs sm:text-sm focus:outline-none focus:border-[#2F4B73] focus:bg-white transition-all"
                  />
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                </div>
                {errors.email && <p className="text-[11px] text-rose-500 mt-1">{errors.email}</p>}
              </div>

              {/* Phone */}
              <div>
                <label className="block text-[11px] font-display uppercase tracking-wider text-slate-700 font-semibold mb-1">
                  Telephone
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    placeholder="e.g. 0300 8765432"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50/60 text-slate-900 text-xs sm:text-sm focus:outline-none focus:border-[#2F4B73] focus:bg-white transition-all"
                  />
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
                </div>
                {errors.phone && <p className="text-[11px] text-rose-500 mt-1">{errors.phone}</p>}
              </div>

              {/* Password & Confirm */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-display uppercase tracking-wider text-slate-700 font-semibold mb-1">
                    Password
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      placeholder="Min. 8 characters"
                      value={formData.password}
                      onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                      className="w-full pl-9 pr-8 py-2.5 rounded-xl border border-slate-200 bg-slate-50/60 text-slate-900 text-xs focus:outline-none focus:border-[#2F4B73] focus:bg-white transition-all"
                    />
                    <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-2.5 top-3 text-slate-400 hover:text-slate-600"
                    >
                      {showPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  {errors.password && <p className="text-[10px] text-rose-500 mt-1">{errors.password}</p>}
                </div>

                <div>
                  <label className="block text-[11px] font-display uppercase tracking-wider text-slate-700 font-semibold mb-1">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <input
                      type={showConfirmPassword ? 'text' : 'password'}
                      placeholder="Repeat password"
                      value={formData.confirmPassword}
                      onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                      className="w-full pl-9 pr-8 py-2.5 rounded-xl border border-slate-200 bg-slate-50/60 text-slate-900 text-xs focus:outline-none focus:border-[#2F4B73] focus:bg-white transition-all"
                    />
                    <Lock className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3" />
                    <button
                      type="button"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      className="absolute right-2.5 top-3 text-slate-400 hover:text-slate-600"
                    >
                      {showConfirmPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                  {errors.confirmPassword && (
                    <p className="text-[10px] text-rose-500 mt-1">{errors.confirmPassword}</p>
                  )}
                </div>
              </div>

              {/* Terms Checkbox */}
              <div className="pt-1">
                <label className="flex items-start gap-2.5 cursor-pointer select-none">
                  <input
                    type="checkbox"
                    checked={formData.agreeTerms}
                    onChange={(e) => setFormData({ ...formData, agreeTerms: e.target.checked })}
                    className="w-4 h-4 mt-0.5 rounded text-[#1B2A44] border-slate-300 focus:ring-0 cursor-pointer"
                  />
                  <span className="text-[11px] text-slate-600 font-body leading-tight">
                    I agree to Avenue's Representation Terms, Confidential Non-Disclosure Agreements, and Private Client Privacy Policy.
                  </span>
                </label>
                {errors.agreeTerms && (
                  <p className="text-[11px] text-rose-500 mt-1">{errors.agreeTerms}</p>
                )}
              </div>

              {/* Submit Button */}
              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3.5 px-6 rounded-full bg-[#1B2A44] hover:bg-[#2F4B73] text-white font-display font-bold text-xs uppercase tracking-widest transition-all shadow-md flex items-center justify-between group cursor-pointer disabled:opacity-60"
                >
                  <span>{loading ? 'Creating Account...' : 'Create Account'}</span>
                  <span className="w-6 h-6 rounded-full bg-white text-[#1B2A44] flex items-center justify-center group-hover:scale-105 transition-transform">
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </button>
              </div>

              <div className="pt-3 text-center">
                <span className="text-xs text-slate-500 font-body">
                  Already have an account?{' '}
                  <Link
                    to="/login"
                    className="font-display uppercase tracking-wider text-xs font-bold text-[#1B2A44] hover:text-[#2F4B73]"
                  >
                    Sign In
                  </Link>
                </span>
              </div>
            </form>
          </div>
        </div>

        {/* Right Half: Mirrored Rounded Villa Image with Glass Quote Card */}
        <div className="lg:col-span-6 relative hidden lg:block overflow-hidden p-8 sm:p-10 flex flex-col justify-between">
          <div className="absolute inset-0 z-0">
            <SafeImage
              src={HERO_ASSETS.authVillaMirrored}
              alt="Avenue Modern Architecture Design"
              className="w-full h-full object-cover scale-105"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0e1726]/90 via-[#1B2A44]/35 to-transparent" />
          </div>

          {/* Top Brand Watermark Overlay */}
          <div className="relative z-10 flex items-center justify-between text-white">
            <Link to="/" className="font-display font-bold text-2xl tracking-tighter text-white">
              Avenue
            </Link>
            <span className="text-[10px] font-display uppercase tracking-widest text-white/70 glass-card-subtle px-3 py-1 rounded-full">
              Discreet Membership
            </span>
          </div>

          {/* Glass Quote Card */}
          <div className="relative z-10 glass-panel rounded-3xl p-6 text-white border border-white/20 shadow-xl backdrop-blur-xl">
            <div className="flex items-center gap-1.5 text-amber-300 text-xs mb-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span className="font-display uppercase tracking-widest text-[10px] text-white/80">
                Property Advisory
              </span>
            </div>
            <p className="font-display font-bold text-xl sm:text-2xl tracking-tight text-white leading-snug">
              "Built for generational peace of mind."
            </p>
            <p className="font-body text-xs text-white/70 mt-2">
              Join Pakistan's leading business families, high-net-worth investors, and overseas Pakistani buyers.
            </p>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
